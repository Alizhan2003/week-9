package com.company;

public class part2 {

}
