import java.io.FileInputStream;

import java.io.ObjectInputStream;

import java.io.Serializable;
public class ObjectCreate {

        public static void main(String[] args) throws Exception {


            //with clone I used here
            Student ob3 = (Student) ob2.clone();
            ob3.display();


            FileInputStream fIn = new FileInputStream("file.txt");
            ObjectInputStream obIn = new ObjectInputStream(fIn);

            Student ob4 = (Student) obIn.readObject();
            ob4.display();
        }
    }


    class Student implements Cloneable, Serializable {
        public void display() throws Exception {
            System.out.println("Display ");
        }
        @Override
        protected Object clone() throws CloneNotSupportedException {
            return super.clone();
        }
    }
}
